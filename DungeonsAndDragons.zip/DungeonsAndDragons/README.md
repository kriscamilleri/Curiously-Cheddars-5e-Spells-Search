# Curiously Cheddars 5e Spell Search

> Dungeons and dragons 5e spell browser, search and filter.

# developer info

> Backend built using .NET Core and MongoDB. Frontend written in Vue using webpack and npm. 

# motivation

> There didn't yet a exist a mobile friendly spell search. Nor one that worked well if the internet died after page load. So I made one. 

